# HummAPP · hummapp.fi (Julkinen vain luku -sivusto)

Euroopan unionin osarahoittama Kaustisen seutukunnan HummAPP-pilotin julkinen verkkosivusto.
Sivusto on täysin staattinen (HTML/CSS/JS) eikä sisällä kirjautumista tai muokkaustoimintoja.

## Julkaisu GitHub Pagesiin (ilman web-hotellia)
1. Pura tämän ZIP-paketin kaikki tiedostot (ml. `CNAME`, `.nojekyll`, `index.html`, `config.js`, `public-data.json`, `assets/`) julkiseen GitHub-repositorioon (`main`-haaran juureen).
2. Avaa GitHubissa `Settings -> Pages`, valitse Source: `Deploy from a branch`, Branch: `main` ja `/ (root)`.
3. Lisää verkkotunnuksen palveluntarjoajalla DNS-tietueet:
   - `A` `@` -> `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - `CNAME` `www` -> `<github-tunnuksesi>.github.io`
4. Kun haluat sivuston näyttävän Synology NASin live-datan, aseta `config.js`-tiedostossa:
   `apiBaseUrl: "https://api.hummapp.fi"` (tai pilottipalvelimen HTTPS-osoite)
   ja ohjaa DNS `CNAME` `api` -> `<oma-nas>.synology.me`.
   Jos `apiBaseUrl` on tyhjä (`""`), sivusto käyttää `public-data.json`-tilannekuvaa.
